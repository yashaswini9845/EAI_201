import pandas as pd
from sklearn.model_selection import train_test_split

# Load labeled dataset
df = pd.read_csv("final_features_dataset_labeled.csv")

# Select features
features = [
    'avg_age', 'avg_overall_rating', 'avg_potential',
    'win_rate', 'goal_ratio', 'goal_diff_ratio', 'team_strength_index'
]
X = df[features]
y = df['finalist']

# Split data (70/30 split with stratification)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, stratify=y if y.nunique() > 1 else None, random_state=42
)

print("Data Preparation Complete")
print("=" * 50)
print(f"Training set: {X_train.shape[0]} samples")
print(f"Testing set:  {X_test.shape[0]} samples")
print(f"Features used: {len(features)}")
print(f"\nFeature list:")
for i, feat in enumerate(features, 1):
    print(f"  {i}. {feat}")
print("\nClass distribution in training set:")
print(f"  Finalists: {y_train.sum()}")
print(f"  Non-finalists: {(y_train == 0).sum()}")
print("\nClass distribution in testing set:")
print(f"  Finalists: {y_test.sum()}")
print(f"  Non-finalists: {(y_test == 0).sum()}")
print("=" * 50)
