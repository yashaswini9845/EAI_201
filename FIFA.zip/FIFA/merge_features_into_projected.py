# ------------------------------------------------------------
# merge_features_into_projected.py
# ------------------------------------------------------------
# Purpose: Merge feature columns into projected team dataset
# ------------------------------------------------------------

import pandas as pd

# Load both datasets
teams = pd.read_csv("projected_full_48.csv")
features = pd.read_csv("final_features_dataset.csv")

# Normalize team names for safer matching
def clean_name(name):
    if pd.isnull(name):
        return ""
    name = str(name).strip().lower()
    name = name.replace("usa", "united states")
    name = name.replace("south korea", "korea republic")
    return name

teams["team_name_clean"] = teams["team_name"].apply(clean_name)
features["team_name_clean"] = features["team_name"].apply(clean_name)

# Merge using cleaned names
merged = pd.merge(teams, features, on="team_name_clean", how="left", suffixes=("", "_feat"))

# Drop extra column
merged.drop(columns=["team_name_clean"], inplace=True)

# If duplicate team_name columns exist, keep one
if "team_name_feat" in merged.columns:
    merged.drop(columns=["team_name_feat"], inplace=True)

# Save the updated dataset
merged.to_csv("projected_full_48.csv", index=False)

print("✅ Successfully merged feature columns into projected_full_48.csv")
print("Columns now:", merged.columns.tolist())
