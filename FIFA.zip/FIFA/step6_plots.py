import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
import numpy as np

# Load data
df = pd.read_csv("final_features_dataset_labeled.csv")
features = ['avg_age','avg_overall_rating','avg_potential','win_rate','goal_ratio','goal_diff_ratio','team_strength_index']
X = df[features]
y = df['finalist']

# Train model for feature importance
rf = RandomForestClassifier(random_state=42, n_estimators=300)
rf.fit(X, y)
importances = rf.feature_importances_

# Plot 1: Feature Importance
plt.figure(figsize=(10,6))
plt.barh(features, importances, color='skyblue', edgecolor='black')
plt.title("Feature Importance - Random Forest Model", fontsize=14, weight='bold')
plt.xlabel("Importance Score", fontsize=12)
plt.ylabel("Feature", fontsize=12)
plt.tight_layout()
plt.savefig("feature_importance.png", dpi=300)
plt.close()
print("Saved: feature_importance.png")

# Plot 2: Correlation Heatmap
plt.figure(figsize=(10,8))
correlation_matrix = df[features + ['finalist']].corr()
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm', center=0,
            square=True, linewidths=1, cbar_kws={"shrink": 0.8})
plt.title("Feature Correlation Heatmap", fontsize=14, weight='bold')
plt.tight_layout()
plt.savefig("correlation_heatmap.png", dpi=300)
plt.close()
print("Saved: correlation_heatmap.png")

# Plot 3: Distribution of Key Features by Finalist Status
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
key_features = ['avg_overall_rating', 'win_rate', 'goal_ratio', 'team_strength_index']

for idx, feature in enumerate(key_features):
    ax = axes[idx//2, idx%2]
    df[df['finalist']==1][feature].hist(bins=20, alpha=0.6, label='Finalist', ax=ax, color='green')
    df[df['finalist']==0][feature].hist(bins=20, alpha=0.6, label='Non-Finalist', ax=ax, color='red')
    ax.set_xlabel(feature, fontsize=10)
    ax.set_ylabel('Frequency', fontsize=10)
    ax.set_title(f'Distribution: {feature}', fontsize=11, weight='bold')
    ax.legend()
    ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig("feature_distributions.png", dpi=300)
plt.close()
print("Saved: feature_distributions.png")

print("\nAll visualization plots generated successfully!")
