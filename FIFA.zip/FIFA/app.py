# ------------------------------------------------------------
# FIFA 2026 Finalist Predictor – Streamlit App
# ------------------------------------------------------------
# This app loads your trained Random Forest model,
# predicts finalist probabilities for 2026 teams,
# and displays them in a realistic dashboard view.
# ------------------------------------------------------------

import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# PAGE CONFIGURATION
# ------------------------------------------------------------
st.set_page_config(
    page_title="FIFA 2026 Finalist Predictor",
    page_icon="🏆",
    layout="wide"
)

st.title("🏆 FIFA 2026 Finalist Predictor (Percentage Formula)")
st.markdown("""
This app uses a **weighted percentage-based formula** to predict which teams
are most likely to reach the **FIFA 2026 World Cup Final** based on
team performance metrics and player statistics.
""")

# ------------------------------------------------------------
# LOAD PREDICTIONS FROM FORMULA-BASED SYSTEM
# ------------------------------------------------------------
try:
    df = pd.read_csv("final_predictions.csv")
    st.success("✅ Predictions loaded successfully!")
    
    # Load the full dataset for additional team info
    full_data = pd.read_csv("projected_full_48.csv")
    
    # Merge to get confederation and other details
    df = df.merge(full_data[['team_name', 'confederation', 'rank']], on='team_name', how='left')
    
except FileNotFoundError:
    st.error("❌ 'final_predictions.csv' not found. Please run step5_predict_finals.py first.")
    st.stop()

# ------------------------------------------------------------
# DISPLAY RESULTS
# ------------------------------------------------------------
st.header("🔝 Top 10 Predicted Finalists (Percentage-Based Formula)")
top10 = df.sort_values("finalist_probability", ascending=False).head(10).copy()
top10['percentage'] = (top10['finalist_probability'] * 100).round(2)

display_cols = ['team_name', 'percentage', 'confederation', 'rank', 'predicted_finalist']
top10_display = top10[display_cols].rename(columns={
    'team_name': 'Team',
    'percentage': 'Finalist %',
    'confederation': 'Confederation',
    'rank': 'FIFA Rank',
    'predicted_finalist': 'Predicted Finalist'
})
st.dataframe(top10_display, use_container_width=True)

# ------------------------------------------------------------
# TEAM CHECKER (Individual Probability)
# ------------------------------------------------------------
st.header("🔍 Check a Team’s Probability")
team = st.selectbox("Select a team:", df["team_name"].unique())
prob = df.loc[df["team_name"] == team, "finalist_probability"].values[0]
prediction = int(df.loc[df["team_name"] == team, "predicted_finalist"].values[0])

if prediction == 1:
    st.success(f"✅ {team} has a **{prob*100:.2f}%** chance of reaching the Final.")
else:
    st.warning(f"⚠️ {team} has a **{prob*100:.2f}%** chance — less likely to reach the Final.")

# ------------------------------------------------------------
# BAR CHART – Realistic Probabilities
# ------------------------------------------------------------
st.header("📊 Top 15 Teams by Predicted Probability")

df_sorted = df.sort_values("finalist_probability", ascending=False).head(15)
fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.barh(
    df_sorted["team_name"],
    df_sorted["finalist_probability"],
    color=plt.cm.Blues(df_sorted["finalist_probability"] / max(df_sorted["finalist_probability"])),
    edgecolor="black"
)

# Add labels to bars
for bar in bars:
    width = bar.get_width()
    ax.text(width + 0.01, bar.get_y() + bar.get_height() / 2,
            f"{width*100:.1f}%", va="center", fontsize=9, color="black")

ax.set_xlabel("Probability of Reaching the Final", fontsize=11)
ax.set_ylabel("Team Name", fontsize=11)
ax.set_title("Top 15 Teams – Percentage-Based Prediction", fontsize=13, weight="bold")
ax.set_xlim(0, max(df_sorted["finalist_probability"]) + 0.05)
ax.invert_yaxis()
ax.grid(axis="x", linestyle="--", alpha=0.6)
st.pyplot(fig)

# ------------------------------------------------------------
# SUMMARY SECTION
# ------------------------------------------------------------
st.header("📊 Formula & Methodology")
st.markdown("""
### FIFA Ranking-Based Prediction Formula

**Weights Applied (Total = 100%):**
- **FIFA World Ranking (30%):** Lower rank number = higher score
- **FIFA Points (15%):** Official FIFA ranking points
- **Team Rating (15%):** Average overall player rating
- **Team Strength Index (12%):** Composite strength metric
- **Win Rate (10%):** Historical match win percentage
- **Team Potential (8%):** Average player potential
- **Goal Ratio (5%):** Goals scored vs goals conceded
- **Goal Difference (3%):** Average goal difference per match
- **Squad Age (2%):** Younger squads get slight advantage

**Calculation:**
Each team receives a score from 0-100% based on normalized features with FIFA rankings as the primary factor.

**Threshold:** Teams scoring **≥50%** are predicted as potential finalists.

**Total Teams Predicted:** {predicted_count} teams exceed the 50% threshold.

**Top 3 Teams:**
- 🥇 Argentina (Rank #1) - World Champions
- 🥈 France (Rank #2) - Defending Champions 
- 🥉 Spain (Rank #3) - European Powerhouse
""".format(predicted_count=df['predicted_finalist'].sum()))

st.caption("FIFA 2026 Finalist Prediction Project – FIFA Ranking-Based System")

