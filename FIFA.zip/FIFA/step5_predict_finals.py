import pandas as pd
import numpy as np

# Load labeled dataset
df = pd.read_csv("final_features_dataset_labeled.csv")

# Load full dataset with FIFA rankings and points
full_df = pd.read_csv("projected_full_48.csv")

# Merge to get FIFA points if not already present
if 'total.points' not in df.columns:
    df = df.merge(full_df[['team_name', 'total.points']], on='team_name', how='left')

# Define features
features = [
    'avg_age', 'avg_overall_rating', 'avg_potential',
    'win_rate', 'goal_ratio', 'goal_diff_ratio', 'team_strength_index'
]

print("Calculating percentage-based predictions using FIFA rankings...")
print("="*60)

# Normalize features to 0-100 scale
normalized_df = df.copy()

# Normalize FIFA rank (lower rank = better, so invert)
rank_min = df['rank'].min()
rank_max = df['rank'].max()
normalized_df['rank_norm'] = 100 - ((df['rank'] - rank_min) / (rank_max - rank_min)) * 100

# Normalize FIFA points
points_min = df['total.points'].min()
points_max = df['total.points'].max()
normalized_df['points_norm'] = ((df['total.points'] - points_min) / (points_max - points_min)) * 100

# Normalize other features to percentage (0-100)
for feature in features:
    min_val = df[feature].min()
    max_val = df[feature].max()
    if max_val > min_val:
        normalized_df[f'{feature}_norm'] = ((df[feature] - min_val) / (max_val - min_val)) * 100
    else:
        normalized_df[f'{feature}_norm'] = 50  # default if all values are same

# Age is better when younger for potential, so invert it
normalized_df['avg_age_norm'] = 100 - normalized_df['avg_age_norm']

# Define weights for each feature (total = 100%)
# FIFA rankings heavily weighted as per your requirements
weights = {
    'rank_norm': 30,                   # 30% - FIFA World Ranking (most important)
    'points_norm': 15,                 # 15% - FIFA Points
    'avg_overall_rating_norm': 15,     # 15% - Current team quality
    'team_strength_index_norm': 12,    # 12% - Overall team strength
    'win_rate_norm': 10,               # 10% - Historical performance
    'avg_potential_norm': 8,           # 8% - Future potential
    'goal_ratio_norm': 5,              # 5% - Attacking strength
    'goal_diff_ratio_norm': 3,         # 3% - Goal difference efficiency
    'avg_age_norm': 2                  # 2% - Squad age (younger is better)
}

print("\nWeights applied (FIFA Ranking Priority):")
for feature, weight in weights.items():
    print(f"  {feature.replace('_norm', ''):30s}: {weight:2d}%")

# Calculate weighted score (0-100)
df['finalist_score'] = 0
for feature, weight in weights.items():
    df['finalist_score'] += (normalized_df[feature] * weight / 100)

# Convert score to probability (0-1 scale)
df['finalist_probability'] = df['finalist_score'] / 100

# Apply threshold for finalist prediction
threshold = 0.50  # 50% threshold
df['predicted_finalist'] = (df['finalist_probability'] >= threshold).astype(int)

# Sort by probability
final_predictions = df[['team_name', 'rank', 'total.points', 'confederation', 
                        'finalist_score', 'finalist_probability', 'predicted_finalist']].copy()
final_predictions = final_predictions.sort_values(by='finalist_probability', ascending=False)

# Save predictions
final_predictions.to_csv("final_predictions.csv", index=False)

# Display results
print("\n" + "=" * 60)
print("PREDICTION RESULTS (FIFA Ranking-Based Formula)")
print("=" * 60)
print("\n🏆 Top 10 Predicted Finalists:")
top10 = final_predictions.head(10)[['team_name', 'confederation', 'rank', 'total.points', 
                                     'finalist_probability', 'predicted_finalist']].copy()
top10['finalist_percentage'] = (top10['finalist_probability'] * 100).round(2)

for idx, row in top10.iterrows():
    rank_emoji = "🥇" if row['rank'] == 1 else "🥈" if row['rank'] == 2 else "🥉" if row['rank'] == 3 else "  "
    status = "✅" if row['predicted_finalist'] == 1 else "❌"
    print(f"{rank_emoji} {row['team_name']:15s} ({row['confederation']:10s}) - Rank #{row['rank']:2.0f} - {row['finalist_percentage']:5.2f}% {status}")

print(f"\n\nTotal teams predicted as finalists (threshold >= {threshold*100}%): {df['predicted_finalist'].sum()}")
print(f"Probability range: {df['finalist_probability'].min()*100:.2f}% to {df['finalist_probability'].max()*100:.2f}%")

print("\nPredictions saved to: final_predictions.csv")
print("=" * 60)
