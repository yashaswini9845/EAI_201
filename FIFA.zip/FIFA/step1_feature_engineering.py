import pandas as pd
import numpy as np

# Load the master dataset
df = pd.read_csv("final_cleaned_master_dataset.csv")

print("Initial dataset shape:", df.shape)
print("Columns:", df.columns.tolist())

# Derived features
df['goal_ratio'] = df['goals_for'] / (df['goals_against'] + 1e-6)
df['goal_diff_ratio'] = df['goal_diff'] / (df['matches_played'] + 1e-6)
df['rating_efficiency'] = df['avg_overall_rating'] / (df['avg_potential'] + 1e-6)
df['team_strength_index'] = (
    0.4 * df['avg_overall_rating'] +
    0.3 * df['avg_potential'] +
    0.2 * df['win_rate'] * 100 +
    0.1 * df['attack_strength']
)

# Fill missing values with median
df.fillna(df.median(numeric_only=True), inplace=True)

# Save the engineered dataset
df.to_csv("final_features_dataset.csv", index=False)
print("\nFeature engineering complete!")
print("Saved as: final_features_dataset.csv")
print("Final shape:", df.shape)
print("\nNew features created:")
print("- goal_ratio")
print("- goal_diff_ratio")
print("- rating_efficiency")
print("- team_strength_index")
