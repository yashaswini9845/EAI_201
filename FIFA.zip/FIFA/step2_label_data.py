# step2_label_data.py
import pandas as pd

# Load your feature-engineered dataset
df = pd.read_csv("final_features_dataset.csv")

# Define historical finalists based on recent World Cup finals
# 2022: Argentina vs France
# 2018: France vs Croatia
# 2014: Germany vs Argentina
# 2010: Spain vs Netherlands
# 2006: Italy vs France
# Previous strong performers: Brazil, England, Uruguay
past_finalists = [
    "Argentina", "France", "Croatia", "Germany", "Brazil", 
    "Netherlands", "Spain", "Italy", "England", "Uruguay"
]

# Create the 'finalist' label (1 = reached final, 0 = not finalist)
df["finalist"] = df["team_name"].apply(lambda x: 1 if x in past_finalists else 0)

# Save the labeled dataset
df.to_csv("final_features_dataset_labeled.csv", index=False)
print("Added 'finalist' column based on historical data")
print("Saved as: final_features_dataset_labeled.csv")
print("\nTarget distribution:")
print(df["finalist"].value_counts())
print("\nFinalist teams in dataset:")
print(df[df["finalist"]==1]["team_name"].unique())
