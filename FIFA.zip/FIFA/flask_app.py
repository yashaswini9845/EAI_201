from flask import Flask, render_template, jsonify, request
import pandas as pd
import json

app = Flask(__name__)

# Load predictions data
predictions_df = pd.read_csv('final_predictions.csv')
full_data_df = pd.read_csv('projected_full_48.csv')

# Merge data - select only needed columns from full_data to avoid duplicates
data = predictions_df.merge(
    full_data_df[['team_name', 'status', 'squad_count', 'avg_age', 
                  'avg_overall_rating', 'avg_potential', 'win_rate', 'goal_ratio', 
                  'team_strength_index']], 
    on='team_name', 
    how='left'
)

# Rename confederation column if it exists (it's already in predictions_df)
if 'confederation' not in data.columns and 'confederation_x' in data.columns:
    data['confederation'] = data['confederation_x']

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html')

@app.route('/api/top-teams')
def get_top_teams():
    """API endpoint for top 10 teams"""
    top_teams = data.nlargest(10, 'finalist_probability')
    result = []
    
    for idx, row in top_teams.iterrows():
        result.append({
            'rank': int(idx + 1),
            'team_name': row['team_name'],
            'confederation': row['confederation'],
            'fifa_rank': int(row['rank']),
            'fifa_points': int(row['total.points']),
            'probability': round(row['finalist_probability'] * 100, 2),
            'rating': round(row['avg_overall_rating'], 1),
            'status': row['status']
        })
    
    return jsonify(result)

@app.route('/api/all-teams')
def get_all_teams():
    """API endpoint for all teams"""
    all_teams = data.sort_values('finalist_probability', ascending=False)
    result = []
    
    for idx, row in all_teams.iterrows():
        result.append({
            'team_name': row['team_name'],
            'confederation': row['confederation'],
            'fifa_rank': int(row['rank']),
            'fifa_points': int(row['total.points']),
            'probability': round(row['finalist_probability'] * 100, 2),
            'rating': round(row['avg_overall_rating'], 1),
            'potential': round(row['avg_potential'], 1),
            'win_rate': round(row['win_rate'] * 100, 1),
            'goal_ratio': round(row['goal_ratio'], 2),
            'team_strength': round(row['team_strength_index'], 1),
            'status': row['status'],
            'predicted_finalist': int(row['predicted_finalist'])
        })
    
    return jsonify(result)

@app.route('/api/team/<team_name>')
def get_team_details(team_name):
    """API endpoint for individual team details"""
    team_data = data[data['team_name'] == team_name]
    
    if len(team_data) == 0:
        return jsonify({'error': 'Team not found'}), 404
    
    row = team_data.iloc[0]
    
    result = {
        'team_name': row['team_name'],
        'confederation': row['confederation'],
        'fifa_rank': int(row['rank']),
        'fifa_points': int(row['total.points']),
        'probability': round(row['finalist_probability'] * 100, 2),
        'score': round(row['finalist_score'], 2),
        'predicted_finalist': int(row['predicted_finalist']),
        'status': row['status'],
        'squad_count': int(row['squad_count']),
        'avg_age': round(row['avg_age'], 1),
        'avg_rating': round(row['avg_overall_rating'], 1),
        'avg_potential': round(row['avg_potential'], 1),
        'win_rate': round(row['win_rate'] * 100, 1),
        'goal_ratio': round(row['goal_ratio'], 2),
        'team_strength': round(row['team_strength_index'], 1)
    }
    
    return jsonify(result)

@app.route('/api/stats')
def get_stats():
    """API endpoint for overall statistics"""
    stats = {
        'total_teams': len(data),
        'predicted_finalists': int(data['predicted_finalist'].sum()),
        'avg_probability': round(data['finalist_probability'].mean() * 100, 2),
        'highest_prob': {
            'team': data.loc[data['finalist_probability'].idxmax(), 'team_name'],
            'value': round(data['finalist_probability'].max() * 100, 2)
        },
        'lowest_prob': {
            'team': data.loc[data['finalist_probability'].idxmin(), 'team_name'],
            'value': round(data['finalist_probability'].min() * 100, 2)
        },
        'by_confederation': data.groupby('confederation')['predicted_finalist'].sum().to_dict()
    }
    
    return jsonify(stats)

@app.route('/api/teams-list')
def get_teams_list():
    """API endpoint for teams list (for dropdowns)"""
    teams = data.sort_values('team_name')[['team_name', 'confederation', 'rank']].to_dict('records')
    return jsonify(teams)

@app.route('/api/predict-match', methods=['POST'])
def predict_match():
    """API endpoint to predict match outcome between two teams"""
    req_data = request.get_json()
    
    home_team = req_data.get('home_team')
    away_team = req_data.get('away_team')
    
    if not home_team or not away_team:
        return jsonify({'error': 'Both teams must be selected'}), 400
    
    if home_team == away_team:
        return jsonify({'error': 'Please select different teams'}), 400
    
    # Get team data
    home = data[data['team_name'] == home_team].iloc[0]
    away = data[data['team_name'] == away_team].iloc[0]
    
    # Calculate match prediction based on multiple factors
    # Factors: rating, potential, win_rate, team_strength, goal_ratio
    home_score = (
        home['avg_overall_rating'] * 0.3 +
        home['team_strength_index'] * 0.25 +
        home['win_rate'] * 100 * 0.2 +
        home['goal_ratio'] * 10 * 0.15 +
        home['finalist_probability'] * 100 * 0.1
    )
    
    away_score = (
        away['avg_overall_rating'] * 0.3 +
        away['team_strength_index'] * 0.25 +
        away['win_rate'] * 100 * 0.2 +
        away['goal_ratio'] * 10 * 0.15 +
        away['finalist_probability'] * 100 * 0.1
    )
    
    # Add home advantage (5%)
    home_score *= 1.05
    
    # Calculate probabilities
    total = home_score + away_score
    home_win_prob = round((home_score / total) * 100, 2)
    away_win_prob = round((away_score / total) * 100, 2)
    draw_prob = round(min(home_win_prob, away_win_prob) * 0.3, 2)  # Draw is 30% of lower probability
    
    # Adjust to ensure total is around 100%
    remaining = 100 - draw_prob
    home_win_prob = round((home_score / total) * remaining, 2)
    away_win_prob = round(100 - home_win_prob - draw_prob, 2)
    
    # Predicted score based on goal ratios and team strength
    home_goals = round(home['goal_ratio'] * (home['team_strength_index'] / 70), 1)
    away_goals = round(away['goal_ratio'] * (away['team_strength_index'] / 70), 1)
    
    # Determine winner
    if home_win_prob > away_win_prob:
        winner = home_team
        confidence = home_win_prob
    else:
        winner = away_team
        confidence = away_win_prob
    
    result = {
        'home_team': {
            'name': home_team,
            'confederation': home['confederation'],
            'fifa_rank': int(home['rank']),
            'rating': round(home['avg_overall_rating'], 1),
            'win_rate': round(home['win_rate'] * 100, 1),
            'team_strength': round(home['team_strength_index'], 1),
            'finalist_prob': round(home['finalist_probability'] * 100, 2)
        },
        'away_team': {
            'name': away_team,
            'confederation': away['confederation'],
            'fifa_rank': int(away['rank']),
            'rating': round(away['avg_overall_rating'], 1),
            'win_rate': round(away['win_rate'] * 100, 1),
            'team_strength': round(away['team_strength_index'], 1),
            'finalist_prob': round(away['finalist_probability'] * 100, 2)
        },
        'prediction': {
            'home_win': home_win_prob,
            'draw': draw_prob,
            'away_win': away_win_prob,
            'predicted_score': f"{int(home_goals)}-{int(away_goals)}",
            'winner': winner,
            'confidence': confidence
        }
    }
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
