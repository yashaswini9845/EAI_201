# ------------------------------------------------------------
# SCRIPT 1 — Build Player ↔ Team Mapping
# Output: player_team_mapping.csv
# ------------------------------------------------------------

import pandas as pd
import numpy as np
from datetime import datetime

# === 1️⃣ LOAD DATASETS ===
teams = pd.read_csv("projected_full_48.csv")   # 48 teams
players = pd.read_csv("data/player-data-full-2025-june.csv", low_memory=False)

# === 2️⃣ CLEAN COLUMN NAMES ===
teams.columns = teams.columns.str.strip().str.lower().str.replace(' ', '_')
players.columns = players.columns.str.strip().str.lower().str.replace(' ', '_')

# === 3️⃣ PREPARE TEAMS ===
teams['team_key'] = teams['team_name'].astype(str).str.lower().str.replace(' ', '').str.replace('-', '')
teams = teams.reset_index().rename(columns={'index':'team_id'})

# === 4️⃣ CLEAN & PREPARE PLAYER DATA ===
players['dob'] = pd.to_datetime(players['dob'], errors='coerce')
current_year = datetime.now().year
players['age'] = current_year - players['dob'].dt.year

players_core = players[['player_id','name','country_name','age','overall_rating','potential']].copy()
players_core['country_key'] = players_core['country_name'].astype(str).str.lower().str.replace(' ', '').str.replace('-', '')

# === 5️⃣ MAP PLAYERS TO TEAMS USING NATIONALITY ===
team_keys = dict(zip(teams['team_key'], teams['team_name']))
players_core['team_assigned'] = players_core['country_key'].map(team_keys)

assigned = players_core[players_core['team_assigned'].notna()].copy()
unassigned = players_core[players_core['team_assigned'].isna()].copy()

# === 6️⃣ BUILD TEAM SQUADS ===
squad_size = 23
squads = {}
for _, row in teams.iterrows():
    tname = row['team_name']
    squads[tname] = assigned[assigned['team_assigned']==tname].copy()

# Fill remaining players for teams needing extra members
pool = unassigned.sort_values(by=['overall_rating','potential'], ascending=False).reset_index(drop=True)
qualified = teams[teams['status'].astype(str).str.lower().str.contains('qual', na=False)]['team_name'].tolist()
other_teams = teams[~teams['team_name'].isin(qualified)]['team_name'].tolist()

def fill_squads(team_list, pool_df, squads_dict):
    pool_idx = 0
    for t in team_list:
        cur = squads_dict.get(t, pd.DataFrame(columns=pool_df.columns))
        need = squad_size - len(cur)
        if need > 0 and pool_idx < len(pool_df):
            take = pool_df.iloc[pool_idx:pool_idx+need].copy()
            take['team_assigned'] = t
            squads_dict[t] = pd.concat([cur, take], ignore_index=True)
            pool_idx += need
    return pool_df.iloc[pool_idx:].reset_index(drop=True)

pool = fill_squads(qualified, pool, squads)
pool = fill_squads(other_teams, pool, squads)

# === 7️⃣ COMBINE ALL SQUADS INTO ONE CSV ===
mapping_rows = []
for t, df in squads.items():
    df = df.copy()
    df['team_name'] = t
    mapping_rows.append(df[['team_name','player_id','name','age','overall_rating','potential']])

player_team_mapping = pd.concat(mapping_rows, ignore_index=True)
player_team_mapping = player_team_mapping.drop_duplicates(subset=['player_id'])

# === 8️⃣ SAVE THE PLAYER-TEAM MAPPING ===
player_team_mapping.to_csv("player_team_mapping.csv", index=False)

print("Player-team mapping created successfully!")
print("Shape:", player_team_mapping.shape)
print("Columns:", list(player_team_mapping.columns))
print("\nFirst 5 rows:")
print(player_team_mapping.head())
print("\nTeams covered:", player_team_mapping['team_name'].nunique())
print("Total players mapped:", len(player_team_mapping))
