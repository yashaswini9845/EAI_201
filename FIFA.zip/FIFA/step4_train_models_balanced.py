# step4_train_models_balanced.py
# ------------------------------------------------------------
# Purpose: Train and evaluate Logistic Regression & Random Forest
# models on FIFA dataset to learn finalist patterns.
# ------------------------------------------------------------

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score
from imblearn.over_sampling import RandomOverSampler
import joblib

# ------------------------------------------------------------
# Load labeled dataset
# ------------------------------------------------------------
df = pd.read_csv("final_features_dataset_labeled.csv")

features = [
    "avg_age",
    "avg_overall_rating",
    "avg_potential",
    "win_rate",
    "goal_ratio",
    "goal_diff_ratio",
    "team_strength_index"
]
target = "finalist"

X = df[features]
y = df[target]

# ------------------------------------------------------------
# Split dataset (stratified)
# ------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# ------------------------------------------------------------
# Handle imbalance
# ------------------------------------------------------------
ros = RandomOverSampler(random_state=42)
X_train_res, y_train_res = ros.fit_resample(X_train, y_train)

# ------------------------------------------------------------
# Scale features
# ------------------------------------------------------------
scaler = StandardScaler()
X_train_res_scaled = scaler.fit_transform(X_train_res)
X_test_scaled = scaler.transform(X_test)

# ------------------------------------------------------------
# Train models
# ------------------------------------------------------------
lr = LogisticRegression(max_iter=1000, random_state=42)
rf = RandomForestClassifier(random_state=42, n_estimators=300, max_depth=6)

# Calibrate Random Forest probabilities (for realism)
rf_calibrated = CalibratedClassifierCV(rf, method='isotonic', cv=3)

# Fit models
lr.fit(X_train_res_scaled, y_train_res)
rf_calibrated.fit(X_train_res, y_train_res)

# ------------------------------------------------------------
# Evaluate models
# ------------------------------------------------------------
y_pred_lr = lr.predict(X_test_scaled)
y_pred_rf = rf_calibrated.predict(X_test)
y_prob_lr = lr.predict_proba(X_test_scaled)[:, 1]
y_prob_rf = rf_calibrated.predict_proba(X_test)[:, 1]

print("\n--- Logistic Regression ---")
print("Accuracy:", accuracy_score(y_test, y_pred_lr))
print(classification_report(y_test, y_pred_lr, zero_division=0))
print("ROC-AUC:", roc_auc_score(y_test, y_prob_lr))

print("\n--- Random Forest (Calibrated) ---")
print("Accuracy:", accuracy_score(y_test, y_pred_rf))
print(classification_report(y_test, y_pred_rf, zero_division=0))
print("ROC-AUC:", roc_auc_score(y_test, y_prob_rf))

# ------------------------------------------------------------
# Save model and scaler
# ------------------------------------------------------------
joblib.dump(rf_calibrated, "random_forest_calibrated.pkl")
joblib.dump(scaler, "scaler.pkl")
print("✅ Model and scaler saved successfully for prediction use.")

# ------------------------------------------------------------
# Save training results for analysis
# ------------------------------------------------------------
df["finalist_probability_rf"] = rf_calibrated.predict_proba(X)[:, 1]
df["predicted_finalist_rf"] = (df["finalist_probability_rf"] >= 0.35).astype(int)
df.to_csv("final_predictions_balanced.csv", index=False)

print("✅ Saved final_predictions_balanced.csv with model probabilities.")
