# FIFA 2026 Finalist Prediction - Complete Pipeline Execution Script
# This script runs all steps in sequence to generate predictions

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "FIFA 2026 Finalist Prediction Pipeline" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Python is installed
try {
    $pythonVersion = python --version
    Write-Host "Python detected: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Python not found. Please install Python 3.8 or higher." -ForegroundColor Red
    exit 1
}

# Step 0: Check required files
Write-Host "`n[Step 0] Checking required files..." -ForegroundColor Yellow
if (-Not (Test-Path "final_cleaned_master_dataset.csv")) {
    Write-Host "ERROR: final_cleaned_master_dataset.csv not found!" -ForegroundColor Red
    exit 1
}
if (-Not (Test-Path "projected_full_48.csv")) {
    Write-Host "ERROR: projected_full_48.csv not found!" -ForegroundColor Red
    exit 1
}
Write-Host "Required files found." -ForegroundColor Green

# Step 1: Feature Engineering
Write-Host "`n[Step 1] Running feature engineering..." -ForegroundColor Yellow
python step1_feature_engineering.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Feature engineering failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Feature engineering completed successfully." -ForegroundColor Green

# Step 2: Label Data
Write-Host "`n[Step 2] Labeling historical finalists..." -ForegroundColor Yellow
python step2_label_data.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Data labeling failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Data labeling completed successfully." -ForegroundColor Green

# Step 3: Prepare Model Data
Write-Host "`n[Step 3] Preparing model data (train/test split)..." -ForegroundColor Yellow
python step3_prepare_model_data.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Data preparation failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Data preparation completed successfully." -ForegroundColor Green

# Step 4: Train Models
Write-Host "`n[Step 4] Training machine learning models..." -ForegroundColor Yellow
python step4_train_models_balanced.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Model training failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Model training completed successfully." -ForegroundColor Green

# Step 5: Generate Predictions
Write-Host "`n[Step 5] Generating predictions..." -ForegroundColor Yellow
python step5_predict_finals.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Prediction generation failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Predictions generated successfully." -ForegroundColor Green

# Step 6: Create Visualizations
Write-Host "`n[Step 6] Creating visualizations..." -ForegroundColor Yellow
python step6_plots.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Visualization generation failed!" -ForegroundColor Red
    exit 1
}
Write-Host "Visualizations created successfully." -ForegroundColor Green

# Summary
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Pipeline Execution Complete!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Output Files Generated:" -ForegroundColor Green
Write-Host "  - final_features_dataset.csv" -ForegroundColor White
Write-Host "  - final_features_dataset_labeled.csv" -ForegroundColor White
Write-Host "  - final_predictions_balanced.csv" -ForegroundColor White
Write-Host "  - final_predictions.csv" -ForegroundColor White
Write-Host "  - random_forest_calibrated.pkl" -ForegroundColor White
Write-Host "  - scaler.pkl" -ForegroundColor White
Write-Host "  - feature_importance.png" -ForegroundColor White
Write-Host "  - correlation_heatmap.png" -ForegroundColor White
Write-Host "  - feature_distributions.png" -ForegroundColor White
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "  1. Review predictions in final_predictions_balanced.csv" -ForegroundColor White
Write-Host "  2. Check visualizations (*.png files)" -ForegroundColor White
Write-Host "  3. Run web app: streamlit run app.py" -ForegroundColor White
Write-Host ""
