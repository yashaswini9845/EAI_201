"""
FIFA 2026 World Cup Predictor - Run Script
==========================================
This script starts the Flask web application.

Usage:
    python run.py
    
Then open your browser to: http://localhost:5000
"""

from flask_app import app

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🏆 FIFA 2026 World Cup Predictor")
    print("="*60)
    print("\n📊 Starting Flask web application...")
    print("\n🌐 Open your browser and navigate to:")
    print("   → http://localhost:5000")
    print("   → http://127.0.0.1:5000")
    print("\n💡 Press CTRL+C to stop the server\n")
    print("="*60 + "\n")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
