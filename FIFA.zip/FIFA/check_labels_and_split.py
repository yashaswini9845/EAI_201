import pandas as pd
from sklearn.model_selection import train_test_split
from collections import Counter

print("=" * 60)
print("DATA VALIDATION AND INSPECTION")
print("=" * 60)

# Load labeled dataset
df = pd.read_csv("final_features_dataset_labeled.csv")
print("\n[1] Dataset Overview")
print(f"    Shape: {df.shape}")
print(f"    Columns: {len(df.columns)}")

# Check the target distribution
print("\n[2] Target Distribution (Finalist Label)")
print(df['finalist'].value_counts(dropna=False))
print(f"    Finalists: {df['finalist'].sum()}")
print(f"    Non-finalists: {(df['finalist']==0).sum()}")
print(f"    Class imbalance ratio: 1:{(df['finalist']==0).sum() / max(df['finalist'].sum(), 1):.1f}")

# Show rows that are labeled 1 (finalists)
print("\n[3] Teams Labeled as Finalists")
finalist_teams = df[df['finalist']==1][['team_name', 'avg_overall_rating', 'win_rate', 'team_strength_index']]
print(finalist_teams.to_string(index=False))

# Basic features check
features = ['avg_age','avg_overall_rating','avg_potential','win_rate','goal_ratio','goal_diff_ratio','team_strength_index']
print("\n[4] Missing Values in Feature Columns")
missing_check = df[features].isnull().sum()
if missing_check.sum() == 0:
    print("    No missing values found.")
else:
    print(missing_check[missing_check > 0])

# Feature statistics
print("\n[5] Feature Statistics Summary")
print(df[features].describe().round(2))

# Split then look at train/test distribution
X = df[features]
y = df['finalist']
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, 
    stratify=y if y.nunique() > 1 else None
)

print("\n[6] Train/Test Split Information")
print(f"    Train shape: {X_train.shape}")
print(f"    Test shape:  {X_test.shape}")
print(f"    Train target counts: {dict(Counter(y_train))}")
print(f"    Test target counts:  {dict(Counter(y_test))}")

# Data quality checks
print("\n[7] Data Quality Checks")
print(f"    Duplicate rows: {df.duplicated().sum()}")
print(f"    Teams with zero matches: {(df['matches_played']==0).sum()}")
print(f"    Teams with invalid win_rate: {(df['win_rate']>1).sum() + (df['win_rate']<0).sum()}")

print("\n" + "=" * 60)
print("VALIDATION COMPLETE")
print("=" * 60)
