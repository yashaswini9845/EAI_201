# FIFA 2026 World Cup Finalist Prediction

## Project Overview

This project uses machine learning to predict which teams are most likely to reach the FIFA 2026 World Cup final. The prediction model is based on historical team performance, player statistics, and derived performance metrics.

## Project Structure

```
fifa-2026-predictor/
├── data/
│   ├── fifa_2025_clean.csv              # Cleaned FIFA data from Kaggle
│   └── player-data-full-2025-june.csv   # Raw player data
├── scrape.py                            # Download data from Kaggle
├── player_team_mapping.py               # Map players to national teams
├── merge_features_into_projected.py     # Merge features into projected teams
├── step1_feature_engineering.py         # Create derived features
├── step2_label_data.py                  # Label historical finalists
├── step3_prepare_model_data.py          # Split data for training
├── step4_train_models_balanced.py       # Train and save models
├── step5_predict_finals.py              # Make predictions
├── step6_plots.py                       # Generate visualizations
├── check_labels_and_split.py            # Validate data
├── app.py                               # Streamlit web application
├── final_cleaned_master_dataset.csv     # Master dataset with team stats
├── projected_full_48.csv                # 48 teams for 2026 prediction
└── README.md                            # This file
```

## Features Used

### Base Features
- **avg_age**: Average age of squad players
- **avg_overall_rating**: Average FIFA overall rating
- **avg_potential**: Average player potential
- **win_rate**: Historical win percentage
- **matches_played**: Total matches played
- **goals_for**: Total goals scored
- **goals_against**: Total goals conceded

### Derived Features
- **goal_ratio**: Goals scored vs goals conceded ratio
- **goal_diff_ratio**: Goal difference per match
- **rating_efficiency**: Rating vs potential ratio
- **team_strength_index**: Composite metric (40% rating + 30% potential + 20% win_rate + 10% attack_strength)

## Installation

### Prerequisites
```bash
Python 3.8+
pip install -r requirements.txt
```

### Required Packages
```
pandas
numpy
scikit-learn
imbalanced-learn
matplotlib
seaborn
streamlit
joblib
kaggle
```

### Kaggle API Setup
1. Create a Kaggle account at https://www.kaggle.com
2. Go to Account Settings > API > Create New Token
3. Place `kaggle.json` in:
   - Windows: `C:\Users\<username>\.kaggle\kaggle.json`
   - Linux/Mac: `~/.kaggle/kaggle.json`

## Usage

### Step-by-Step Execution

#### 1. Download Data
```bash
python scrape.py
```
Downloads FIFA 2025 player data from Kaggle.

#### 2. Create Player-Team Mapping
```bash
python player_team_mapping.py
```
Maps players to their national teams based on nationality.

#### 3. Feature Engineering
```bash
python step1_feature_engineering.py
```
Creates derived features from base statistics.

#### 4. Label Data
```bash
python step2_label_data.py
```
Labels historical World Cup finalists for training.

#### 5. Prepare Model Data
```bash
python step3_prepare_model_data.py
```
Splits data into training and testing sets.

#### 6. Train Models
```bash
python step4_train_models_balanced.py
```
Trains Logistic Regression and Random Forest models with class balancing.

Output files:
- `random_forest_calibrated.pkl`
- `scaler.pkl`
- `final_predictions_balanced.csv`

#### 7. Generate Visualizations
```bash
python step6_plots.py
```
Creates plots:
- Feature importance
- Correlation heatmap
- Feature distributions

#### 8. Run Web Application
```bash
streamlit run app.py
```
Launches interactive dashboard at http://localhost:8501

## Model Details

### Algorithms Used
1. **Logistic Regression**: Baseline linear model
2. **Random Forest**: Primary model with 300 trees, max_depth=6

### Model Improvements
- **Class Balancing**: RandomOverSampler to handle imbalanced finalist data
- **Calibration**: Isotonic regression for realistic probability estimates
- **Feature Scaling**: StandardScaler for normalized inputs

### Evaluation Metrics
- Accuracy
- Precision, Recall, F1-Score
- ROC-AUC Score

## Historical Finalists (Training Labels)

Teams labeled as finalists based on recent World Cup finals:
- Argentina (2014, 2022 Winner)
- France (2006, 2018 Winner, 2022 Runner-up)
- Germany (2014 Winner)
- Brazil (Multiple finals)
- Netherlands (2010 Runner-up)
- Spain (2010 Winner)
- Italy (2006 Winner)
- Croatia (2018 Runner-up)
- England (Historical performance)
- Uruguay (Historical performance)

## Prediction Threshold

The model uses a **0.35 probability threshold** to classify teams as potential finalists. This threshold was chosen to balance precision and recall.

## Results

Top predicted finalists are saved in:
- `fifa2026_final_predictions.csv` (from Streamlit app)
- `final_predictions_balanced.csv` (from training script)

## Visualizations

Generated plots include:
1. **Feature Importance**: Shows which features matter most
2. **Correlation Heatmap**: Feature relationships
3. **Distribution Plots**: Compares finalists vs non-finalists

## Web Application Features

The Streamlit app provides:
- Top 10 predicted finalists table
- Team-specific probability checker
- Interactive bar chart of top 15 teams
- Model explanation and methodology

## Limitations

1. **Historical Bias**: Model trained on past performance may not capture emerging teams
2. **Data Currency**: Based on 2025 player ratings
3. **Qualification Status**: Some teams may not qualify for 2026
4. **Sample Size**: Limited number of historical finalists for training

## Future Improvements

- Include tournament draw/bracket simulation
- Add injury/form data
- Incorporate coaching staff metrics
- Real-time data updates
- Ensemble methods combining multiple models

## Author

FIFA 2026 Prediction Project

## License

This project is for educational purposes.

## Acknowledgments

- Data source: Kaggle FIFA Player Dataset
- FIFA ratings from SoFIFA
- Scikit-learn for ML algorithms
- Streamlit for web interface
