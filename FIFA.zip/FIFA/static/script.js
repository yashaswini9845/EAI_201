// Global data storage
let allTeamsData = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadStats();
    loadTopTeams();
    loadAllTeams();
    loadTeamsForPredictor();
    setupEventListeners();
});

// Load overall statistics
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const stats = await response.json();
        
        document.getElementById('total-teams').textContent = stats.total_teams;
        document.getElementById('predicted-finalists').textContent = stats.predicted_finalists;
        document.getElementById('accuracy').textContent = stats.highest_prob.value + '%';
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load top 10 teams
async function loadTopTeams() {
    try {
        const response = await fetch('/api/top-teams');
        const teams = await response.json();
        
        const grid = document.getElementById('top-teams-grid');
        grid.innerHTML = '';
        
        teams.forEach((team, index) => {
            const card = createTeamCard(team, index + 1);
            grid.innerHTML += card;
        });
        
        // Add click listeners to team cards
        addTeamCardListeners();
    } catch (error) {
        console.error('Error loading top teams:', error);
        document.getElementById('top-teams-grid').innerHTML = 
            '<p class="error">Error loading teams. Please refresh the page.</p>';
    }
}

// Create team card HTML
function createTeamCard(team, rank) {
    const probabilityClass = team.probability >= 70 ? 'probability-high' : 
                            team.probability >= 50 ? 'probability-medium' : 'probability-low';
    
    const medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : rank;
    
    return `
        <div class="team-card" data-team="${team.team_name}">
            <div class="team-rank">${medal}</div>
            <div class="team-header">
                <h3 class="team-name">${team.team_name}</h3>
                <div class="team-meta">
                    <span><i class="fas fa-globe"></i> ${team.confederation}</span>
                    <span><i class="fas fa-ranking-star"></i> FIFA #${team.fifa_rank}</span>
                    <span><i class="fas fa-star"></i> ${team.rating}</span>
                </div>
            </div>
            <div class="probability-bar">
                <div class="probability-label">
                    <span>Finalist Probability</span>
                    <span class="probability-value ${probabilityClass}">${team.probability}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${team.probability}%"></div>
                </div>
            </div>
            <div class="team-stats">
                <div class="stat-item">
                    <div class="stat-value">${team.fifa_points}</div>
                    <div class="stat-label-small">FIFA Points</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.status.includes('Qualified') ? '✅' : '📊'}</div>
                    <div class="stat-label-small">${team.status.includes('Qualified') ? 'Qualified' : 'Projected'}</div>
                </div>
            </div>
        </div>
    `;
}

// Load all teams
async function loadAllTeams() {
    try {
        const response = await fetch('/api/all-teams');
        allTeamsData = await response.json();
        
        displayAllTeams(allTeamsData);
    } catch (error) {
        console.error('Error loading all teams:', error);
    }
}

// Display all teams in table
function displayAllTeams(teams) {
    const container = document.getElementById('all-teams-list');
    
    if (teams.length === 0) {
        container.innerHTML = '<p class="no-results">No teams found</p>';
        return;
    }
    
    let tableHTML = `
        <table class="teams-table">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Team</th>
                    <th>Confederation</th>
                    <th>FIFA Rank</th>
                    <th>Probability</th>
                    <th>Rating</th>
                    <th>Win Rate</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    teams.forEach((team, index) => {
        const probabilityClass = team.probability >= 70 ? 'probability-high' : 
                                team.probability >= 50 ? 'probability-medium' : 'probability-low';
        
        tableHTML += `
            <tr class="team-row" data-team="${team.team_name}">
                <td>${index + 1}</td>
                <td class="team-name-cell">${team.team_name}</td>
                <td>${team.confederation}</td>
                <td>#${team.fifa_rank}</td>
                <td class="probability-cell ${probabilityClass}">${team.probability}%</td>
                <td>${team.rating}</td>
                <td>${team.win_rate}%</td>
                <td>${team.status.includes('Qualified') ? '✅ Qualified' : '📊 Projected'}</td>
            </tr>
        `;
    });
    
    tableHTML += `
            </tbody>
        </table>
    `;
    
    container.innerHTML = tableHTML;
    
    // Add click listeners to table rows
    document.querySelectorAll('.team-row').forEach(row => {
        row.addEventListener('click', function() {
            const teamName = this.dataset.team;
            showTeamDetails(teamName);
        });
    });
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    const searchInput = document.getElementById('team-search');
    if (searchInput) {
        searchInput.addEventListener('input', filterTeams);
    }
    
    // Confederation filter
    const confFilter = document.getElementById('confederation-filter');
    if (confFilter) {
        confFilter.addEventListener('change', filterTeams);
    }
    
    // Match predictor listeners
    const homeSelect = document.getElementById('homeTeamSelect');
    const awaySelect = document.getElementById('awayTeamSelect');
    const predictBtn = document.getElementById('predictBtn');
    
    if (homeSelect) {
        homeSelect.addEventListener('change', handleTeamSelection);
    }
    if (awaySelect) {
        awaySelect.addEventListener('change', handleTeamSelection);
    }
    if (predictBtn) {
        predictBtn.addEventListener('click', predictMatch);
    }
    
    // Modal close
    const modal = document.getElementById('team-modal');
    const closeBtn = document.querySelector('.modal-close');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }
    
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Filter teams based on search and confederation
function filterTeams() {
    const searchTerm = document.getElementById('team-search').value.toLowerCase();
    const confederation = document.getElementById('confederation-filter').value;
    
    let filteredTeams = allTeamsData.filter(team => {
        const matchesSearch = team.team_name.toLowerCase().includes(searchTerm);
        const matchesConf = confederation === 'all' || team.confederation === confederation;
        return matchesSearch && matchesConf;
    });
    
    displayAllTeams(filteredTeams);
}

// Add click listeners to team cards
function addTeamCardListeners() {
    document.querySelectorAll('.team-card').forEach(card => {
        card.addEventListener('click', function() {
            const teamName = this.dataset.team;
            showTeamDetails(teamName);
        });
    });
}

// Show team details in modal
async function showTeamDetails(teamName) {
    try {
        const response = await fetch(`/api/team/${encodeURIComponent(teamName)}`);
        const team = await response.json();
        
        const modal = document.getElementById('team-modal');
        const detailsContainer = document.getElementById('team-details');
        
        const probabilityClass = team.probability >= 70 ? 'probability-high' : 
                                team.probability >= 50 ? 'probability-medium' : 'probability-low';
        
        detailsContainer.innerHTML = `
            <div class="team-details-header">
                <h2 class="team-name">${team.team_name}</h2>
                <div class="team-meta">
                    <span><i class="fas fa-globe"></i> ${team.confederation}</span>
                    <span><i class="fas fa-ranking-star"></i> FIFA Rank #${team.fifa_rank}</span>
                    <span><i class="fas fa-trophy"></i> ${team.fifa_points} Points</span>
                </div>
            </div>
            
            <div class="probability-bar" style="margin: 30px 0;">
                <div class="probability-label">
                    <span style="font-size: 1.2rem;">Finalist Probability</span>
                    <span class="probability-value ${probabilityClass}" style="font-size: 2.5rem;">${team.probability}%</span>
                </div>
                <div class="progress-bar" style="height: 20px;">
                    <div class="progress-fill" style="width: ${team.probability}%"></div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 30px;">
                <div class="stat-item">
                    <div class="stat-value">${team.status}</div>
                    <div class="stat-label-small">Status</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.squad_count}</div>
                    <div class="stat-label-small">Squad Size</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.avg_age}</div>
                    <div class="stat-label-small">Avg Age</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.avg_rating}</div>
                    <div class="stat-label-small">Team Rating</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.avg_potential}</div>
                    <div class="stat-label-small">Team Potential</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.win_rate}%</div>
                    <div class="stat-label-small">Win Rate</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.goal_ratio}</div>
                    <div class="stat-label-small">Goal Ratio</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.team_strength}</div>
                    <div class="stat-label-small">Strength Index</div>
                </div>
            </div>
            
            <div style="margin-top: 30px; padding: 20px; background: ${team.predicted_finalist ? '#e8f5e9' : '#fff3e0'}; border-radius: 10px; text-align: center;">
                <p style="font-size: 1.2rem; font-weight: 600; color: ${team.predicted_finalist ? '#2e7d32' : '#ef6c00'};">
                    ${team.predicted_finalist ? '✅ Predicted to reach the Final!' : '⚠️ Less likely to reach the Final'}
                </p>
            </div>
        `;
        
        modal.style.display = 'block';
    } catch (error) {
        console.error('Error loading team details:', error);
    }
}

// ===== MATCH PREDICTOR FUNCTIONS =====

// Load teams for predictor dropdowns
async function loadTeamsForPredictor() {
    try {
        const response = await fetch('/api/teams-list');
        const teams = await response.json();
        
        const homeSelect = document.getElementById('homeTeamSelect');
        const awaySelect = document.getElementById('awayTeamSelect');
        
        if (!homeSelect || !awaySelect) {
            console.error('Team select elements not found');
            return;
        }
        
        teams.forEach(team => {
            const option1 = document.createElement('option');
            option1.value = team.team_name;
            option1.textContent = `${team.team_name} (FIFA #${team.rank})`;
            homeSelect.appendChild(option1);
            
            const option2 = document.createElement('option');
            option2.value = team.team_name;
            option2.textContent = `${team.team_name} (FIFA #${team.rank})`;
            awaySelect.appendChild(option2);
        });
    } catch (error) {
        console.error('Error loading teams for predictor:', error);
    }
}

// Handle team selection
async function handleTeamSelection(event) {
    const selectId = event.target.id;
    const teamName = event.target.value;
    
    if (teamName) {
        // Load team preview
        try {
            const response = await fetch(`/api/team/${encodeURIComponent(teamName)}`);
            const team = await response.json();
            
            const previewId = selectId === 'homeTeamSelect' ? 'homeTeamInfo' : 'awayTeamInfo';
            const preview = document.getElementById(previewId);
            
            if (preview) {
                preview.innerHTML = `
                    <h4>⚽ ${team.team_name}</h4>
                    <p><i class="fas fa-trophy"></i> <strong>FIFA Rank:</strong> #${team.fifa_rank}</p>
                    <p><i class="fas fa-star"></i> <strong>Rating:</strong> ${team.avg_rating}</p>
                    <p><i class="fas fa-chart-line"></i> <strong>Win Rate:</strong> ${team.win_rate}%</p>
                    <p><i class="fas fa-bullseye"></i> <strong>Finalist Prob:</strong> ${team.probability}%</p>
                `;
                preview.classList.add('active');
            }
        } catch (error) {
            console.error('Error loading team preview:', error);
        }
    } else {
        // Reset preview
        const previewId = selectId === 'homeTeamSelect' ? 'homeTeamInfo' : 'awayTeamInfo';
        const preview = document.getElementById(previewId);
        if (preview) {
            preview.innerHTML = `
                <div class="preview-placeholder">
                    <i class="fas fa-futbol"></i>
                    <p>Select a team to see details</p>
                </div>
            `;
            preview.classList.remove('active');
        }
    }
    
    // Enable predict button if both teams selected
    const homeTeam = document.getElementById('homeTeamSelect').value;
    const awayTeam = document.getElementById('awayTeamSelect').value;
    const predictBtn = document.getElementById('predictBtn');
    
    if (predictBtn) {
        if (homeTeam && awayTeam && homeTeam !== awayTeam) {
            predictBtn.disabled = false;
        } else {
            predictBtn.disabled = true;
        }
    }
}

// Predict match outcome
async function predictMatch() {
    const homeTeam = document.getElementById('homeTeamSelect').value;
    const awayTeam = document.getElementById('awayTeamSelect').value;
    
    if (!homeTeam || !awayTeam) {
        alert('Please select both teams');
        return;
    }
    
    if (homeTeam === awayTeam) {
        alert('Please select different teams');
        return;
    }
    
    try {
        const response = await fetch('/api/predict-match', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                home_team: homeTeam,
                away_team: awayTeam
            })
        });
        
        const result = await response.json();
        
        if (result.error) {
            alert(result.error);
            return;
        }
        
        displayMatchPrediction(result);
    } catch (error) {
        console.error('Error predicting match:', error);
        alert('Error predicting match. Please try again.');
    }
}

// Display match prediction results
function displayMatchPrediction(result) {
    const container = document.getElementById('matchPrediction');
    
    if (!container) {
        console.error('Match prediction container not found');
        return;
    }
    
    const html = `
        <div class="prediction-header">
            <h3>🏆 Match Prediction</h3>
            <div class="prediction-score">${result.prediction.predicted_score}</div>
            <p style="color: #666; font-size: 1.1rem; margin-top: 1rem;">AI-Powered Analysis</p>
        </div>
        
        <div class="prediction-teams">
            <div class="prediction-team" style="background: linear-gradient(135deg, rgba(76,175,80,0.1), rgba(255,255,255,1)); border-left: 5px solid #4CAF50;">
                <h4>🏠 ${result.home_team.name}</h4>
                <div class="team-stat"><span><i class="fas fa-trophy"></i> FIFA Rank</span><span>#${result.home_team.fifa_rank}</span></div>
                <div class="team-stat"><span><i class="fas fa-star"></i> Rating</span><span>${result.home_team.rating}</span></div>
                <div class="team-stat"><span><i class="fas fa-chart-line"></i> Win Rate</span><span>${result.home_team.win_rate}%</span></div>
                <div class="team-stat"><span><i class="fas fa-dumbbell"></i> Team Strength</span><span>${result.home_team.team_strength}</span></div>
                <div class="team-stat"><span><i class="fas fa-bullseye"></i> Finalist Prob</span><span>${result.home_team.finalist_prob}%</span></div>
            </div>
            
            <div style="display: flex; align-items: center; justify-content: center; padding: 2rem;">
                <div class="vs-circle" style="width: 80px; height: 80px; font-size: 1.8rem;">
                    <span class="vs-text">VS</span>
                </div>
            </div>
            
            <div class="prediction-team" style="background: linear-gradient(135deg, rgba(33,150,243,0.1), rgba(255,255,255,1)); border-right: 5px solid #2196F3;">
                <h4>✈️ ${result.away_team.name}</h4>
                <div class="team-stat"><span><i class="fas fa-trophy"></i> FIFA Rank</span><span>#${result.away_team.fifa_rank}</span></div>
                <div class="team-stat"><span><i class="fas fa-star"></i> Rating</span><span>${result.away_team.rating}</span></div>
                <div class="team-stat"><span><i class="fas fa-chart-line"></i> Win Rate</span><span>${result.away_team.win_rate}%</span></div>
                <div class="team-stat"><span><i class="fas fa-dumbbell"></i> Team Strength</span><span>${result.away_team.team_strength}</span></div>
                <div class="team-stat"><span><i class="fas fa-bullseye"></i> Finalist Prob</span><span>${result.away_team.finalist_prob}%</span></div>
            </div>
        </div>
        
        <div class="prediction-probabilities" style="background: linear-gradient(135deg, #667eea, #764ba2); padding: 2.5rem; border-radius: 20px; margin-bottom: 2rem; box-shadow: 0 15px 40px rgba(102,126,234,0.3);">
            <h4 style="color: white; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">📊 Win Probabilities</h4>
            <div class="prob-bars">
                <div class="prob-bar">
                    <span class="prob-label" style="color: white; font-weight: 700;">${result.home_team.name} Win</span>
                    <div class="prob-track">
                        <div class="prob-fill home-win" style="width: 0%; transition: width 1.5s ease-in-out 0.3s;">
                            ${result.prediction.home_win}%
                        </div>
                    </div>
                </div>
                <div class="prob-bar">
                    <span class="prob-label" style="color: white; font-weight: 700;">⚖️ Draw</span>
                    <div class="prob-track">
                        <div class="prob-fill draw" style="width: 0%; transition: width 1.5s ease-in-out 0.6s;">
                            ${result.prediction.draw}%
                        </div>
                    </div>
                </div>
                <div class="prob-bar">
                    <span class="prob-label" style="color: white; font-weight: 700;">${result.away_team.name} Win</span>
                    <div class="prob-track">
                        <div class="prob-fill away-win" style="width: 0%; transition: width 1.5s ease-in-out 0.9s;">
                            ${result.prediction.away_win}%
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="prediction-winner" style="position: relative; overflow: hidden;">
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.3) 50%, transparent 70%); background-size: 200% 200%; animation: shimmer 3s infinite;"></div>
            <h3 style="position: relative; z-index: 2;">🏆 Predicted Winner</h3>
            <div class="winner-name" style="position: relative; z-index: 2; text-shadow: 3px 3px 6px rgba(0,0,0,0.15);">${result.prediction.winner}</div>
            <div class="confidence" style="position: relative; z-index: 2; font-weight: 700;">⚡ Confidence: ${result.prediction.confidence}%</div>
        </div>
    `;
    
    container.innerHTML = html;
    container.style.display = 'block';
    
    // Trigger animations after a small delay
    setTimeout(() => {
        const probBars = container.querySelectorAll('.prob-fill');
        probBars.forEach((bar, index) => {
            const width = bar.textContent.trim().replace('%', '');
            bar.style.width = width + '%';
        });
    }, 100);
    
    // Scroll to results
    setTimeout(() => {
        container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 200);
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
