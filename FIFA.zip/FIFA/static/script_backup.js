// Global data storage
let allTeamsData = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadStats();
    loadTopTeams();
    loadAllTeams();
    setupEventListeners();
});

// Load overall statistics
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const stats = await response.json();
        
        document.getElementById('total-teams').textContent = stats.total_teams;
        document.getElementById('predicted-finalists').textContent = stats.predicted_finalists;
        document.getElementById('accuracy').textContent = stats.highest_prob.value + '%';
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load top 10 teams
async function loadTopTeams() {
    try {
        const response = await fetch('/api/top-teams');
        const teams = await response.json();
        
        const grid = document.getElementById('top-teams-grid');
        grid.innerHTML = '';
        
        teams.forEach((team, index) => {
            const card = createTeamCard(team, index + 1);
            grid.innerHTML += card;
        });
        
        // Add click listeners to team cards
        addTeamCardListeners();
    } catch (error) {
        console.error('Error loading top teams:', error);
        document.getElementById('top-teams-grid').innerHTML = 
            '<p class="error">Error loading teams. Please refresh the page.</p>';
    }
}

// Create team card HTML
function createTeamCard(team, rank) {
    const probabilityClass = team.probability >= 70 ? 'probability-high' : 
                            team.probability >= 50 ? 'probability-medium' : 'probability-low';
    
    const medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : rank;
    
    return `
        <div class="team-card" data-team="${team.team_name}">
            <div class="team-rank">${medal}</div>
            <div class="team-header">
                <h3 class="team-name">${team.team_name}</h3>
                <div class="team-meta">
                    <span><i class="fas fa-globe"></i> ${team.confederation}</span>
                    <span><i class="fas fa-ranking-star"></i> FIFA #${team.fifa_rank}</span>
                    <span><i class="fas fa-star"></i> ${team.rating}</span>
                </div>
            </div>
            <div class="probability-bar">
                <div class="probability-label">
                    <span>Finalist Probability</span>
                    <span class="probability-value ${probabilityClass}">${team.probability}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${team.probability}%"></div>
                </div>
            </div>
            <div class="team-stats">
                <div class="stat-item">
                    <div class="stat-value">${team.fifa_points}</div>
                    <div class="stat-label-small">FIFA Points</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.status.includes('Qualified') ? '✅' : '📊'}</div>
                    <div class="stat-label-small">${team.status.includes('Qualified') ? 'Qualified' : 'Projected'}</div>
                </div>
            </div>
        </div>
    `;
}

// Load all teams
async function loadAllTeams() {
    try {
        const response = await fetch('/api/all-teams');
        allTeamsData = await response.json();
        
        displayAllTeams(allTeamsData);
    } catch (error) {
        console.error('Error loading all teams:', error);
    }
}

// Display all teams in table
function displayAllTeams(teams) {
    const container = document.getElementById('all-teams-list');
    
    if (teams.length === 0) {
        container.innerHTML = '<p class="no-results">No teams found</p>';
        return;
    }
    
    let tableHTML = `
        <table class="teams-table">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Team</th>
                    <th>Confederation</th>
                    <th>FIFA Rank</th>
                    <th>Probability</th>
                    <th>Rating</th>
                    <th>Win Rate</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    teams.forEach((team, index) => {
        const probabilityClass = team.probability >= 70 ? 'probability-high' : 
                                team.probability >= 50 ? 'probability-medium' : 'probability-low';
        
        tableHTML += `
            <tr class="team-row" data-team="${team.team_name}">
                <td>${index + 1}</td>
                <td class="team-name-cell">${team.team_name}</td>
                <td>${team.confederation}</td>
                <td>#${team.fifa_rank}</td>
                <td class="probability-cell ${probabilityClass}">${team.probability}%</td>
                <td>${team.rating}</td>
                <td>${team.win_rate}%</td>
                <td>${team.status.includes('Qualified') ? '✅ Qualified' : '📊 Projected'}</td>
            </tr>
        `;
    });
    
    tableHTML += `
            </tbody>
        </table>
    `;
    
    container.innerHTML = tableHTML;
    
    // Add click listeners to table rows
    document.querySelectorAll('.team-row').forEach(row => {
        row.addEventListener('click', function() {
            const teamName = this.dataset.team;
            showTeamDetails(teamName);
        });
    });
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    const searchInput = document.getElementById('team-search');
    searchInput.addEventListener('input', filterTeams);
    
    // Confederation filter
    const confFilter = document.getElementById('confederation-filter');
    confFilter.addEventListener('change', filterTeams);
    
    // Modal close
    const modal = document.getElementById('team-modal');
    const closeBtn = document.querySelector('.modal-close');
    
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Filter teams based on search and confederation
function filterTeams() {
    const searchTerm = document.getElementById('team-search').value.toLowerCase();
    const confederation = document.getElementById('confederation-filter').value;
    
    let filteredTeams = allTeamsData.filter(team => {
        const matchesSearch = team.team_name.toLowerCase().includes(searchTerm);
        const matchesConf = confederation === 'all' || team.confederation === confederation;
        return matchesSearch && matchesConf;
    });
    
    displayAllTeams(filteredTeams);
}

// Add click listeners to team cards
function addTeamCardListeners() {
    document.querySelectorAll('.team-card').forEach(card => {
        card.addEventListener('click', function() {
            const teamName = this.dataset.team;
            showTeamDetails(teamName);
        });
    });
}

// Show team details in modal
async function showTeamDetails(teamName) {
    try {
        const response = await fetch(`/api/team/${encodeURIComponent(teamName)}`);
        const team = await response.json();
        
        const modal = document.getElementById('team-modal');
        const detailsContainer = document.getElementById('team-details');
        
        const probabilityClass = team.probability >= 70 ? 'probability-high' : 
                                team.probability >= 50 ? 'probability-medium' : 'probability-low';
        
        detailsContainer.innerHTML = `
            <div class="team-details-header">
                <h2 class="team-name">${team.team_name}</h2>
                <div class="team-meta">
                    <span><i class="fas fa-globe"></i> ${team.confederation}</span>
                    <span><i class="fas fa-ranking-star"></i> FIFA Rank #${team.fifa_rank}</span>
                    <span><i class="fas fa-trophy"></i> ${team.fifa_points} Points</span>
                </div>
            </div>
            
            <div class="probability-bar" style="margin: 30px 0;">
                <div class="probability-label">
                    <span style="font-size: 1.2rem;">Finalist Probability</span>
                    <span class="probability-value ${probabilityClass}" style="font-size: 2.5rem;">${team.probability}%</span>
                </div>
                <div class="progress-bar" style="height: 20px;">
                    <div class="progress-fill" style="width: ${team.probability}%"></div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 30px;">
                <div class="stat-item">
                    <div class="stat-value">${team.status}</div>
                    <div class="stat-label-small">Status</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.squad_count}</div>
                    <div class="stat-label-small">Squad Size</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.avg_age}</div>
                    <div class="stat-label-small">Avg Age</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.avg_rating}</div>
                    <div class="stat-label-small">Team Rating</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.avg_potential}</div>
                    <div class="stat-label-small">Team Potential</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.win_rate}%</div>
                    <div class="stat-label-small">Win Rate</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.goal_ratio}</div>
                    <div class="stat-label-small">Goal Ratio</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${team.team_strength}</div>
                    <div class="stat-label-small">Strength Index</div>
                </div>
            </div>
            
            <div style="margin-top: 30px; padding: 20px; background: ${team.predicted_finalist ? '#e8f5e9' : '#fff3e0'}; border-radius: 10px; text-align: center;">
                <p style="font-size: 1.2rem; font-weight: 600; color: ${team.predicted_finalist ? '#2e7d32' : '#ef6c00'};">
                    ${team.predicted_finalist ? '✅ Predicted to reach the Final!' : '⚠️ Less likely to reach the Final'}
                </p>
            </div>
        `;
        
        modal.style.display = 'block';
    } catch (error) {
        console.error('Error loading team details:', error);
    }
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
